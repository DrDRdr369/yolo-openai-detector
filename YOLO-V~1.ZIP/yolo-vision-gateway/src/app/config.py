"""Application configuration (env-driven).

Implements: PR-0.

All configuration comes from environment variables (12-factor). The only secret is
GATEWAY_API_KEY; the application MUST fail to start if it is unset (fail closed).

See docs/api-contract.md section 6 for the full config surface.
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration. Loaded from environment / .env."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # REQUIRED secret — no default. Absence must abort startup.
    gateway_api_key: str

    # Model
    model_path: str = "models/yolo11n.onnx"
    model_id: str = "yolo11n"

    # Detection defaults
    conf_threshold: float = 0.25
    iou_threshold: float = 0.45

    # Input limits (enforced BEFORE decode)
    max_image_bytes: int = 10_000_000
    max_image_pixels: int = 4096 * 4096

    # ONNX Runtime execution provider: "cpu" | "openvino"
    onnx_provider: str = "cpu"

    # Server
    host: str = "0.0.0.0"
    port: int = 8000


def get_settings() -> Settings:
    """Return the loaded settings.

    PR-0: implement caching (e.g. functools.lru_cache) and an explicit, clear error when
    GATEWAY_API_KEY is missing so the app fails closed at startup.
    """
    raise NotImplementedError("PR-0: load and cache Settings; fail closed if key unset.")
