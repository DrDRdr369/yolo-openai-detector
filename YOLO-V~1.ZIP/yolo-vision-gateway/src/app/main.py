"""FastAPI application entry point.

Implements: PR-0 (app, /healthz, /v1/models wiring), extended by later PRs.

The execution agent wires routers here and ensures the app fails to start without a valid
configuration (fail closed). Keep this module thin: routing and startup only.
"""

from __future__ import annotations

from fastapi import FastAPI


def create_app() -> FastAPI:
    """Build and configure the FastAPI application.

    PR-0: create app, load settings (fail closed), register the auth dependency, mount the
    /v1/models route and GET /healthz.
    PR-2: mount POST /v1/detections.
    PR-3: mount POST /v1/chat/completions.
    """
    raise NotImplementedError("PR-0: construct app, register routes and startup checks.")


# Uvicorn target: `app.main:app`
# PR-0: assign `app = create_app()` once create_app is implemented.
