"""Bearer-token authentication dependency.

Implements: PR-0.

Rules (see AGENTS.md section 3):
- Single fixed key from settings (GATEWAY_API_KEY).
- Compare in constant time (hmac.compare_digest), never `==`.
- Missing/invalid key -> HTTP 401 with an OpenAI-style error body.
- Never log or echo the key.
"""

from __future__ import annotations

from fastapi import Request


async def require_api_key(request: Request) -> None:
    """FastAPI dependency that authorizes a request or raises 401.

    PR-0: parse the `Authorization: Bearer <token>` header, compare against the configured
    key with hmac.compare_digest, and raise an HTTPException(401) shaped per
    docs/api-contract.md section 5 on any failure.
    """
    raise NotImplementedError("PR-0: constant-time bearer key check, fail closed (401).")
