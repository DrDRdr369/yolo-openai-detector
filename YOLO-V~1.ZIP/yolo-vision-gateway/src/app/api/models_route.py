"""GET /v1/models — list the loaded detection model in OpenAI list shape.

Implements: PR-0.

Response shape: see docs/api-contract.md section 2.
"""

from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.get("/v1/models")
async def list_models() -> dict:
    """Return the loaded model(s) in OpenAI `{object: list, data: [...]}` shape.

    PR-0: return the configured MODEL_ID. This route is also a readiness signal.
    """
    raise NotImplementedError("PR-0: return OpenAI-shaped model list from settings.")
