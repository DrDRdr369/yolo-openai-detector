"""Auth tests.

Implements: PR-0.

Cover: valid key passes; missing key -> 401; wrong key -> 401; app fails to start when
GATEWAY_API_KEY is unset; constant-time comparison path is used.
"""

import pytest


@pytest.mark.skip(reason="PR-0: implement auth tests")
def test_missing_key_returns_401():
    ...


@pytest.mark.skip(reason="PR-0: implement auth tests")
def test_wrong_key_returns_401():
    ...


@pytest.mark.skip(reason="PR-0: implement auth tests")
def test_valid_key_allows_models_route():
    ...
