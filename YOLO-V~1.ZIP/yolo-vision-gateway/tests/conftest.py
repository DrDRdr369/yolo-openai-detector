"""Shared pytest fixtures.

Implements: PR-0 onward.

Provide an httpx ASGI test client, a fake GATEWAY_API_KEY (obviously not real), and golden
image fixtures placed in tests/fixtures/. Tests must be deterministic: pin the model and
seed any randomness.
"""

from __future__ import annotations

import pytest


@pytest.fixture
def api_key() -> str:
    """An obviously-fake key for tests (never a real secret)."""
    return "test-key-not-a-real-secret"


@pytest.fixture
def client():
    """PR-0: build an httpx.AsyncClient against the ASGI app with env configured.

    Set GATEWAY_API_KEY (to the fake key) and a test MODEL_PATH before constructing the app.
    """
    raise NotImplementedError("PR-0: provide an ASGI test client fixture.")
